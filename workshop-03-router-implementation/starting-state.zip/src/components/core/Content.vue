<template>
  <section class="content-info">
    <slot />
  </section>
</template>

<script>
export default {};
</script>

<style></style>
