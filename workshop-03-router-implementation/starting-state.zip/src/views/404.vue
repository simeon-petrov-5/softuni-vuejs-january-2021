<template>
  <section>
    <h1>Uh oh... we have problem!</h1>
    <img src="../assets/error.png" />
  </section>
</template>

<script>
export default {};
</script>

<style></style>
